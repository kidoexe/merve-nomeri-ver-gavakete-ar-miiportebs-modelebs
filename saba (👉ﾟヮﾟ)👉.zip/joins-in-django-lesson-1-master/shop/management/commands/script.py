from django.core.management.base import BaseCommand, CommandError
from django.db.models import Count, Max, Min, Avg, Sum
from shop.models import Item, Category
 


class Command(BaseCommand):
    def handle(self, *args, **options):
        item_count = Item.objects.aaggregate(total=Count('id'))
        print(item_count)
    
    price_stats = Item.objects.aggregate(
    max_price=Max('price'),
    min_price=Min('price'),
    avg_price=Avg('price')
    )
    print(price_stats)

    category_counts = Category.objects.annotate(items_count=Count('items'))
    for category in category_counts:
        print(f"Category: {category.name}, Items Count: {category.items_count}")

    category_prices = Category.objects.annotate(items_price_sum=Sum('items__price'))
    for category in category_prices:
        print(f"Category: {category.name}, Total Price: {category.items_price_sum}")

    items_with_categories = Item.objects.select_related('category')
    for item in items_with_categories:
        print(f"Item: {item.name}, Category: {item.category.name}")

    items_with_tags = Item.objects.prefetch_related('tags')
    for item in items_with_tags:
        tags = item.tags.all()
        print(f"Item: {item.name}, Tags: {[tag.name for tag in tags]}")
